package lk.ac.kln.stu.gunaseka_ps17050.productservice.repository;

import lk.ac.kln.stu.gunaseka_ps17050.productservice.model.Product;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProductRepository extends MongoRepository<Product, String> {
}
